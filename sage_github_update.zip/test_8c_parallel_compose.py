"""
Test 8C — Parallel Composition: FHRR Binding vs Hopfield Union vs NLerp
========================================================================
Author: Ivelin Likov

Tests three mechanisms for composing outputs from two specialist cubes
retrieved in PARALLEL (both queried simultaneously, outputs merged).

Mechanisms:
  1. NLerp (baseline): normalize(v_A + v_B)  — simple spherical average
  2. FHRR binding: FFT-based circular convolution  — creates bound vector
                   recoverable by unbinding
  3. Hopfield union: query BOTH cubes simultaneously via concatenated matrix
                     — lets the geometry decide the right blend
  4. Product-of-Experts: add logits from both cubes before softmax
                         — veto: concept must score high in BOTH cubes

Setup:
  - Cube A stores "when" knowledge (temporal context)
  - Cube B stores "what" knowledge (object identity)
  - Test queries require both: "what was here when X happened?"

Expected: Hopfield union and PoE outperform NLerp on joint queries
          FHRR produces bindable vectors (unbinding accuracy test)

Results: test_8c_parallel_results.json + test_8c_parallel.png
"""

import sys
import os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

import torch
import torch.nn.functional as F
import numpy as np
import json
import time
import math
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from datetime import datetime

try:
    from cube_core_v2_torch import SpatialCubeV2Torch as Cube
    print("Using SpatialCubeV2Torch")
except ImportError:
    class Cube:
        def __init__(self, cube_size=32, embed_dim=64, seed=42, device=None):
            torch.manual_seed(seed)
            self.device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
            self.n_points = cube_size ** 3
            self.embed_dim = embed_dim
            self.embeddings = F.normalize(
                torch.randn(self.n_points, embed_dim, device=self.device), p=2, dim=1)
        def learn_batch(self, pairs, alpha=0.05, **kwargs):
            Q = F.normalize(torch.stack([p[0] for p in pairs]).to(self.device), p=2, dim=1)
            T = F.normalize(torch.stack([p[1] for p in pairs]).to(self.device), p=2, dim=1)
            sims = Q @ self.embeddings.T
            scores = F.softmax(sims / 0.1, dim=1)
            grad = scores.T @ T
            wt   = scores.sum(0).unsqueeze(1)
            mask = wt.squeeze() > 1e-6
            self.embeddings[mask] += alpha * (grad[mask] / wt[mask] - self.embeddings[mask])
            self.embeddings = F.normalize(self.embeddings, p=2, dim=1)
            return 0.0

# ── Config ────────────────────────────────────────────────────────────────────
CUBE_SIZE   = 32
EMBED_DIM   = 64
N_CONCEPTS  = 150
EPOCHS      = 25
BATCH_SIZE  = 32
ALPHA       = 0.05
TEMPERATURE = 0.05
N_RUNS      = 5

device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
print(f"\nDevice: {device}")


# ── Composition mechanisms ────────────────────────────────────────────────────

def retrieve(cube, query, temperature=TEMPERATURE):
    q = F.normalize(query.unsqueeze(0), p=2, dim=1).squeeze(0)
    sims = cube.embeddings @ q
    scores = F.softmax(sims / temperature, dim=0)
    response = (scores.unsqueeze(1) * cube.embeddings).sum(0)
    return F.normalize(response.unsqueeze(0), p=2, dim=1).squeeze(0), sims


def nlerp(va, vb, w=0.5):
    """Normalized linear interpolation — geodesic midpoint on sphere."""
    return F.normalize(w * va + (1 - w) * vb, p=2, dim=0)


def fhrr_bind(va, vb):
    """
    FHRR binding via circular convolution (= element-wise multiply in frequency domain).
    The bound vector approximately encodes both va and vb.
    Unbinding: convolve bound with conjugate of va to recover vb.
    """
    fa = torch.fft.rfft(va)
    fb = torch.fft.rfft(vb)
    bound = torch.fft.irfft(fa * fb, n=va.shape[-1])
    return F.normalize(bound, p=2, dim=0)


def fhrr_unbind(bound, va):
    """Recover vb from bound representation given va."""
    fa = torch.fft.rfft(va)
    fb_bound = torch.fft.rfft(bound)
    fb_approx = fb_bound * torch.conj(fa)
    recovered = torch.fft.irfft(fb_approx, n=bound.shape[-1])
    return F.normalize(recovered, p=2, dim=0)


def hopfield_union(cube_a, cube_b, query, temperature=TEMPERATURE):
    """
    Query both cubes simultaneously via concatenated embedding matrix.
    Single softmax over all N_a + N_b points — cross-cube attention.
    """
    q = F.normalize(query.unsqueeze(0), p=2, dim=1).squeeze(0)
    all_emb = torch.cat([cube_a.embeddings, cube_b.embeddings], dim=0)  # [2N, d]
    sims    = all_emb @ q
    scores  = F.softmax(sims / temperature, dim=0)
    response = (scores.unsqueeze(1) * all_emb).sum(0)
    return F.normalize(response.unsqueeze(0), p=2, dim=1).squeeze(0)


def product_of_experts(cube_a, cube_b, query, temperature=TEMPERATURE):
    """
    Product-of-Experts: for each position i, multiply attention weights
    from both cubes. Works when cubes share the same N-point grid structure
    (same grid size, same index space) — combines evidence from both domains.
    Response is a blend of cube_a embeddings weighted by the product scores.
    """
    q = F.normalize(query.unsqueeze(0), p=2, dim=1).squeeze(0)
    # Get attention weights from each cube independently
    logits_a = cube_a.embeddings @ q / temperature   # (N,)
    logits_b = cube_b.embeddings @ q / temperature   # (N,)
    # Product of experts: add logits = multiply probabilities
    scores = F.softmax(logits_a + logits_b, dim=0)   # (N,)
    # Response: blend cube_a embeddings by product weights
    # (gives the cube_a content most supported by both cubes)
    response = (scores.unsqueeze(1) * cube_a.embeddings).sum(0)
    return F.normalize(response.unsqueeze(0), p=2, dim=1).squeeze(0)


def resonance_merge(cube_a, cube_b, query, temperature=TEMPERATURE, n_iter=5):
    """
    Iterative resonance: repeatedly merge retrieval from both cubes
    until convergence — finds the direction most supported by both.
    """
    va, _ = retrieve(cube_a, query, temperature)
    vb, _ = retrieve(cube_b, query, temperature)
    v = nlerp(va, vb)
    for _ in range(n_iter):
        ra, _ = retrieve(cube_a, v, temperature)
        rb, _ = retrieve(cube_b, v, temperature)
        v = nlerp(ra, rb)
    return v


# ── Training ──────────────────────────────────────────────────────────────────

def train_cube(cube, vecs, epochs=EPOCHS, batch_size=BATCH_SIZE, alpha=ALPHA):
    n = len(vecs)
    for ep in range(epochs):
        perm = torch.randperm(n, device=device)
        for i in range(0, n, batch_size):
            idx = perm[i:i+batch_size]
            batch = vecs[idx]
            pairs = [(batch[j], batch[j]) for j in range(len(idx))]
            cube.learn_batch(pairs, alpha=alpha, beta=0.003,
                             teach_directions=False, momentum=0.9, neg_weight=0.1)


# ── Experiment ────────────────────────────────────────────────────────────────

def run_experiment(seed):
    torch.manual_seed(seed)
    np.random.seed(seed)

    # Generate paired concept spaces
    # Cube A: "context" embeddings (e.g. temporal / situational)
    # Cube B: "content" embeddings (e.g. object / entity)
    # Joint target: the COMBINATION of context + content

    context_vecs = F.normalize(torch.randn(N_CONCEPTS, EMBED_DIM, device=device), p=2, dim=1)

    # Content is related to context via rotation
    torch.manual_seed(seed + 777)
    R = torch.linalg.qr(torch.randn(EMBED_DIM, EMBED_DIM, device=device))[0]
    content_vecs = F.normalize(context_vecs @ R.T, p=2, dim=1)

    # The "ground truth" for a joint query is the NLerp of context+content
    # i.e. what both cubes "agree on"
    joint_targets = F.normalize(context_vecs + content_vecs, p=2, dim=1)

    cube_a = Cube(cube_size=CUBE_SIZE, embed_dim=EMBED_DIM, seed=seed, device=str(device))
    cube_b = Cube(cube_size=CUBE_SIZE, embed_dim=EMBED_DIM, seed=seed+1, device=str(device))

    train_cube(cube_a, context_vecs)
    train_cube(cube_b, content_vecs)

    # Test on held-out joint queries
    n_test = max(5, N_CONCEPTS // 5)
    test_q = joint_targets[-n_test:]         # query with the joint target direction
    test_t = joint_targets[-n_test:]         # and expect to recover it
    # (querying with joint target, expecting to retrieve joint target)
    test_a = context_vecs[-n_test:]
    test_b = content_vecs[-n_test:]

    mechanisms = {
        'nlerp':     [],
        'hopfield':  [],
        'poe':       [],
        'resonance': [],
        'fhrr_bind': [],
    }
    fhrr_unbind_acc = []

    for i in range(n_test):
        q = test_q[i]
        target = test_t[i]

        # NLerp
        va, _ = retrieve(cube_a, q)
        vb, _ = retrieve(cube_b, q)
        out = nlerp(va, vb)
        mechanisms['nlerp'].append(
            F.cosine_similarity(out.unsqueeze(0), target.unsqueeze(0)).item())

        # Hopfield union
        out = hopfield_union(cube_a, cube_b, q)
        mechanisms['hopfield'].append(
            F.cosine_similarity(out.unsqueeze(0), target.unsqueeze(0)).item())

        # Product of experts
        out = product_of_experts(cube_a, cube_b, q)
        mechanisms['poe'].append(
            F.cosine_similarity(out.unsqueeze(0), target.unsqueeze(0)).item())

        # Resonance
        out = resonance_merge(cube_a, cube_b, q)
        mechanisms['resonance'].append(
            F.cosine_similarity(out.unsqueeze(0), target.unsqueeze(0)).item())

        # FHRR binding
        bound = fhrr_bind(va, vb)
        mechanisms['fhrr_bind'].append(
            F.cosine_similarity(bound.unsqueeze(0), target.unsqueeze(0)).item())

        # FHRR unbinding accuracy: recover vb from (bound, va)
        recovered = fhrr_unbind(bound, va)
        fhrr_unbind_acc.append(
            F.cosine_similarity(recovered.unsqueeze(0), vb.unsqueeze(0)).item())

    return {m: float(np.mean(v)) for m, v in mechanisms.items()}, \
           float(np.mean(fhrr_unbind_acc))


# ── Main ──────────────────────────────────────────────────────────────────────
print("\nRunning parallel composition test...")
print("="*60)

mech_names = ['nlerp', 'hopfield', 'poe', 'resonance', 'fhrr_bind']
all_scores = {m: [] for m in mech_names}
all_unbind = []

for run in range(N_RUNS):
    t0 = time.perf_counter()
    scores, unbind_acc = run_experiment(seed=42 + run * 100)
    t1 = time.perf_counter()
    for m in mech_names:
        all_scores[m].append(scores[m])
    all_unbind.append(unbind_acc)
    print(f"\nRun {run+1}/{N_RUNS} ({t1-t0:.1f}s):")
    for m in mech_names:
        print(f"  {m:<12}: Cosine={scores[m]:.4f}")
    print(f"  FHRR unbind accuracy: {unbind_acc:.4f}")

print("\n" + "="*60)
print("SUMMARY (mean cosine similarity to joint target)")
print("="*60)
baseline = float(np.mean(all_scores['nlerp']))
best_m, best_score = 'nlerp', baseline

for m in mech_names:
    mean = float(np.mean(all_scores[m]))
    std  = float(np.std(all_scores[m]))
    delta = mean - baseline
    sign = "↑" if delta > 0.005 else ("↓" if delta < -0.005 else "—")
    print(f"  {m:<12}: {mean:.4f}±{std:.4f}  Δ={delta:+.4f} {sign}")
    if mean > best_score:
        best_score, best_m = mean, m

print(f"\nFHRR unbind accuracy: {float(np.mean(all_unbind)):.4f} "
      f"(how well vb is recovered from bound+va)")
print(f"\nBest mechanism: {best_m} (+{best_score - baseline:.4f} vs NLerp)")

if best_score > baseline + 0.02:
    verdict = f"✓ {best_m.upper()} OUTPERFORMS NLERP"
else:
    verdict = "~ ALL MECHANISMS COMPARABLE — NLerp is sufficient"
print(f"Verdict: {verdict}")

# ── Save + Plot ────────────────────────────────────────────────────────────────
out_data = {
    'metadata': {
        'experiment': 'Test 8C — Parallel Composition',
        'run_date': datetime.now().isoformat(),
        'cube_size': CUBE_SIZE, 'embed_dim': EMBED_DIM,
        'n_concepts': N_CONCEPTS, 'epochs': EPOCHS,
        'n_runs': N_RUNS, 'device': str(device),
    },
    'summary': {
        m: {
            'cosine_mean': float(np.mean(all_scores[m])),
            'cosine_std':  float(np.std(all_scores[m])),
        }
        for m in mech_names
    },
    'fhrr_unbind_acc': float(np.mean(all_unbind)),
    'verdict': verdict,
    'best_mechanism': best_m,
    'improvement_vs_nlerp': best_score - baseline,
}

out_json = 'test_8c_parallel_results.json'
with open(out_json, 'w') as f:
    json.dump(out_data, f, indent=2)

fig, axes = plt.subplots(1, 2, figsize=(13, 5))
fig.suptitle('Test 8C — Parallel Composition\nFHRR Binding vs Hopfield Union vs NLerp vs PoE vs Resonance',
             fontsize=12, fontweight='bold')

means = [float(np.mean(all_scores[m])) for m in mech_names]
stds  = [float(np.std(all_scores[m]))  for m in mech_names]
colors = ['#CC3333', '#2E8B57', '#3366CC', '#FF8C00', '#9932CC']

ax = axes[0]
ax.bar(mech_names, means, yerr=stds, color=colors, alpha=0.85, capsize=5)
ax.axhline(baseline, color='red', linestyle='--', alpha=0.5, label=f'NLerp baseline')
ax.set_ylabel('Cosine Similarity to Joint Target')
ax.set_title('Parallel Composition Accuracy')
ax.legend()

ax = axes[1]
ax.bar(['FHRR unbind\n(vb recovery)'], [float(np.mean(all_unbind))],
       color='#9932CC', alpha=0.85)
ax.set_ylabel('Cosine Similarity')
ax.set_title('FHRR Invertibility\n(how well vb recovers from bound+va)')
ax.set_ylim(0, 1.05)

plt.tight_layout()
out_png = 'test_8c_parallel.png'
plt.savefig(out_png, dpi=150, bbox_inches='tight')
plt.close()

print(f"\nResults: {out_json}")
print(f"Plot:    {out_png}")
print("Done.")
